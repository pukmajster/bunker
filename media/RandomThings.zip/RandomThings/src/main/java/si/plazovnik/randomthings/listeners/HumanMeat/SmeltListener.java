package si.plazovnik.randomthings.listeners.HumanMeat;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.FurnaceSmeltEvent;

import static si.plazovnik.randomthings.utils.Utilities.isHumanFlesh;
import static si.plazovnik.randomthings.utils.Utilities.getCookedHumanFlesh;

public class SmeltListener implements Listener {
    @EventHandler
    public void onItemSmelt(FurnaceSmeltEvent event) {
        if (isHumanFlesh(event.getSource())) {
            event.setResult(getCookedHumanFlesh());
        }
    }
}
