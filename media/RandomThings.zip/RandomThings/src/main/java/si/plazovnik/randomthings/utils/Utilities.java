package si.plazovnik.randomthings.utils;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import si.plazovnik.randomthings.RandomThings;

import java.util.Collections;

public class Utilities {
    private static final NamespacedKey humanFleshKey = new NamespacedKey(RandomThings.getInstance(), "human-flesh");
    private static final NamespacedKey cookedHumanFleshKey = new NamespacedKey(RandomThings.getInstance(), "cooked-human-flesh");

    public static ItemStack getHumanFlesh() {
        ItemStack item = new ItemStack(Material.BEEF, 1);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Človeško Meso").color(TextColor.fromCSSHexString("#FF5733")));
        meta.lore(Collections.singletonList(Component.text("Hmm.. le kakšnega okusa je...", NamedTextColor.DARK_RED).decoration(TextDecoration.ITALIC, true)));
        meta.getPersistentDataContainer().set(humanFleshKey, PersistentDataType.INTEGER, 1);
        item.setItemMeta(meta);
        return item;
    }
    public static ItemStack getCookedHumanFlesh() {
        ItemStack item = new ItemStack(Material.COOKED_BEEF, 1);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Kuhano Človeško Meso").color(TextColor.fromCSSHexString("#FF5733")));
        meta.lore(Collections.singletonList(Component.text("Mmm... okusno..?", NamedTextColor.DARK_RED).decoration(TextDecoration.ITALIC, true)));
        meta.getPersistentDataContainer().set(cookedHumanFleshKey, PersistentDataType.INTEGER, 1);
        item.setItemMeta(meta);
        return item;
    }

    public static boolean isHumanFlesh(ItemStack item) {
        if (item.getItemMeta() == null) {
            return false;
        }
        return item.getItemMeta().getPersistentDataContainer().has(humanFleshKey, PersistentDataType.INTEGER);
    }

    public static boolean isCookedHumanFlesh(ItemStack item) {
        if (item.getItemMeta() == null) {
            return false;
        }
        return item.getItemMeta().getPersistentDataContainer().has(cookedHumanFleshKey, PersistentDataType.INTEGER);
    }
}
