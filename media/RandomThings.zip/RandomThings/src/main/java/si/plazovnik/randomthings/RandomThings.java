package si.plazovnik.randomthings;

import org.bukkit.plugin.java.JavaPlugin;
import si.plazovnik.randomthings.listeners.HumanMeat.ConsumeListener;
import si.plazovnik.randomthings.listeners.HumanMeat.DeathListener;
import si.plazovnik.randomthings.listeners.HumanMeat.SmeltListener;

public class RandomThings extends JavaPlugin {
    private static RandomThings instance;

    @Override
    public void onEnable() {
        instance = this;
        getServer().getPluginManager().registerEvents(new DeathListener(),this);
        getServer().getPluginManager().registerEvents(new SmeltListener(),this);
        getServer().getPluginManager().registerEvents(new ConsumeListener(),this);
        getLogger().info("RandomThings is enabled.");
    }

    @Override
    public void onDisable() {
        getLogger().info("RandomThings is disabled.");
    }

    public static RandomThings getInstance() {
        return instance;
    }
}
