package si.plazovnik.randomthings.listeners.HumanMeat;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import static si.plazovnik.randomthings.utils.Utilities.isHumanFlesh;
import static si.plazovnik.randomthings.utils.Utilities.isCookedHumanFlesh;

public class ConsumeListener implements Listener {
    @EventHandler
    public void onConsumeEvent(PlayerItemConsumeEvent event) {
        ItemStack itemEaten = event.getItem();
        Player player = event.getPlayer();

        if (isHumanFlesh(itemEaten)) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.CONFUSION, 350, 15));
            player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 150, 1));
            player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_DIGGING, 250, 15));
        }
        if (isCookedHumanFlesh(itemEaten)) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.CONFUSION, 100, 5));
            player.addPotionEffect(new PotionEffect(PotionEffectType.LUCK, 250, 1));
            player.addPotionEffect(new PotionEffect(PotionEffectType.HUNGER, 100, 50));
        }
    }
}
