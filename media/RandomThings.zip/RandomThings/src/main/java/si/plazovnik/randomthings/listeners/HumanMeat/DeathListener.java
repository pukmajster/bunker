package si.plazovnik.randomthings.listeners.HumanMeat;

import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;

import static si.plazovnik.randomthings.utils.Utilities.getHumanFlesh;

public class DeathListener implements Listener {
    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.getType() != EntityType.VILLAGER || entity.getKiller() == null) return;
         event.getDrops().add(getHumanFlesh());
    }
}
